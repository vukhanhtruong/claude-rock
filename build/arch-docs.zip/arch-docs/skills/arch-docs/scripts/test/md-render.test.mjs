import { test } from 'node:test';
import assert from 'node:assert/strict';
import { renderMarkdown } from '../lib/md-render.mjs';

test('renders headings with slug ids and collects them', () => {
  const { html, headings } = renderMarkdown('## Core Components\ntext');
  assert.match(html, /<h2 id="core-components">Core Components<\/h2>/);
  assert.deepEqual(headings, [{ level: 2, text: 'Core Components', slug: 'core-components' }]);
});

test('renders tables, links, mermaid fences, likec4 markers', () => {
  const md = '| A | src |\n|---|---|\n| x | observed |\n\n[adr](docs/adr/0001-sample.md)\n\n```mermaid\nerDiagram\n```\n\n<!-- likec4:view index -->';
  const { html } = renderMarkdown(md);
  assert.match(html, /<table>[\s\S]*<td>observed<\/td>/);
  assert.match(html, /<a href="docs\/adr\/0001-sample.md">adr<\/a>/);
  assert.match(html, /diagram-shell[\s\S]*mermaid-canvas/);
  assert.match(html, /<c4-view view-id="index">/);
});

test('strips frontmatter', () => {
  const { html } = renderMarkdown('---\nname: x\n---\n## T');
  assert.doesNotMatch(html, /name: x/);
});

test('makes repeated heading ids unique within a document', () => {
  const { html, headings } = renderMarkdown('## Consequences\n\n## Consequences');
  assert.match(html, /<h2 id="consequences">/);
  assert.match(html, /<h2 id="consequences-2">/);
  assert.deepEqual(headings.map((h) => h.slug), ['consequences', 'consequences-2']);
});

test('keeps heading ids unique across docs sharing a slug registry', () => {
  const seen = new Map();
  renderMarkdown('## Considered Options', seen);
  const { headings } = renderMarkdown('## Considered Options', seen);
  assert.equal(headings[0].slug, 'considered-options-2');
});

test('renders a plain fenced block as preformatted code', () => {
  const md = 'Tree:\n\n```\nroot/\n├── src/\n└── docs/\n```\n\nAfter.';
  const { html } = renderMarkdown(md);
  assert.match(html, /<pre><code>root\/\n├── src\/\n└── docs\/<\/code><\/pre>/);
  assert.doesNotMatch(html, /``/);
  assert.match(html, /<p>After\.<\/p>/);
});

test('escapes html inside a plain fenced block', () => {
  const { html } = renderMarkdown('```json\n{"a": "<b>"}\n```');
  assert.match(html, /<pre><code>\{&quot;a&quot;: &quot;&lt;b&gt;&quot;\}<\/code><\/pre>/);
});

test('renders absolute-URL links with the href intact', () => {
  const { html } = renderMarkdown('[Stripe](https://stripe.com/docs/api)');
  assert.match(html, /<a href="https:\/\/stripe\.com\/docs\/api">Stripe<\/a>/);
});

test('renders h4-h6 as real heading tags with no id', () => {
  const { html, headings } = renderMarkdown('#### Deep\n\n##### Deeper\n\n###### Deepest');
  assert.match(html, /<h4>Deep<\/h4>/);
  assert.match(html, /<h5>Deeper<\/h5>/);
  assert.match(html, /<h6>Deepest<\/h6>/);
  assert.doesNotMatch(html, /<h4 id=/);
  assert.deepEqual(headings, []);
});

test('escapes a quote in a link target so it cannot break out of the href attribute', () => {
  const { html } = renderMarkdown('[x](y"onclick="alert(1))');
  assert.doesNotMatch(html, /"\s*onclick=/);
  assert.match(html, /&quot;/);
});

test('h1 gets a doc-prefixed id and is reported as the page title', () => {
  const { html, title, docId } = renderMarkdown('# Threat Model\n\n## Threats');
  assert.match(html, /<h1 id="doc-threat-model"/);
  assert.equal(title, 'Threat Model');
  assert.equal(docId, 'doc-threat-model');
});

test('doc ids use their own namespace so section slugs keep their numbering', () => {
  const slugs = new Map();
  const docSlugs = new Map();
  renderMarkdown('# Related\n\n## Related', slugs, docSlugs);
  const second = renderMarkdown('# Related\n\n## Related', slugs, docSlugs);
  assert.equal(second.docId, 'doc-related-2');
  assert.equal(second.headings[0].slug, 'related-2');
});

test('a page with no h1 falls back to its first section for a title', () => {
  const { title, docId } = renderMarkdown('## Only A Section');
  assert.equal(title, 'Only A Section');
  assert.equal(docId, null);
});

// Lists had no shape of their own, so every "- item" fell through to the
// paragraph collector and a bulleted block came out as one run-on sentence with
// literal dashes in it. The real doc set has 268 bullets, 22 nested and 45
// numbered items — this was the largest reading defect in the body.
test('bullet lines become a list, not a run-on paragraph', () => {
  const { html } = renderMarkdown('- one\n- two\n- three');
  assert.match(html, /<ul><li>one<\/li><li>two<\/li><li>three<\/li><\/ul>/);
  assert.doesNotMatch(html, /<p>- /);
});

test('numbered lines become an ordered list', () => {
  const { html } = renderMarkdown('1. first\n2. second');
  assert.match(html, /<ol><li>first<\/li><li>second<\/li><\/ol>/);
});

test('an indented bullet nests inside the item above it', () => {
  const { html } = renderMarkdown('- parent\n  - child\n- sibling');
  assert.match(html, /<li>parent<ul><li>child<\/li><\/ul><\/li><li>sibling<\/li>/);
});

test('inline markup still renders inside a list item', () => {
  const { html } = renderMarkdown('- see `code` and **bold** and [a](b.md)');
  assert.match(html, /<li>see <code>code<\/code> and <strong>bold<\/strong> and <a href="b\.md">a<\/a><\/li>/);
});

test('a list ends where the prose resumes', () => {
  const { html } = renderMarkdown('- item\n\nAfter the list.');
  assert.match(html, /<\/ul>\n<p>After the list\.<\/p>/);
});

test('a paragraph is not swallowed into a list that follows it', () => {
  const { html } = renderMarkdown('Lead in:\n- item');
  assert.match(html, /<p>Lead in:<\/p>\n<ul><li>item<\/li><\/ul>/);
});
