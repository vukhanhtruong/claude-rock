import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const fixtures = new URL('./fixtures/docs-pass/', import.meta.url).pathname;

test('render.mjs produces a self-contained index.html', () => {
  const out = mkdtempSync(join(tmpdir(), 'arch-docs-render-'));
  const stub = (name, content) => { const p = join(out, name); writeFileSync(p, content); return p; };
  execFileSync('node', [
    'plugins/arch-docs/skills/arch-docs/scripts/render.mjs',
    '--root', fixtures, '--arch', `${fixtures}ARCHITECTURE.md`,
    '--docs', `${fixtures}docs/adr/0001-sample.md`,
    '--out', out,
    '--likec4-bundle', stub('l.js', '/*likec4*/`@font-face{src:url(https://cdn.jsdelivr.net/f.woff2)format("woff2")}`'),
    '--mermaid-bundle', stub('m.js', '/*mermaid*/'),
    '--theme', 'plugins/arch-docs/skills/arch-docs/assets/mermaid-theme.json',
  ]);
  const html = readFileSync(join(out, 'index.html'), 'utf8');
  assert.match(html, /<h2 id="core-components">/);
  assert.match(html, /href="#core-components"/);
  assert.match(html, /\/\*likec4\*\//);
  assert.match(html, /\/\*mermaid\*\//);
  assert.doesNotMatch(html, /url\(https?:/);
  assert.doesNotMatch(html, /https?:\/\/(?!www\.w3\.org)/);
  // ARCHITECTURE.md heads its own section; anything under docs/adr/ buckets
  // into one collapsed Decision Records block instead of padding the rail.
  assert.match(html, /nav-sec__title[^>]*>Architecture</);
  assert.match(html, /nav-sec__title[^>]*>Decision Records</);
});

test('render.mjs fails loudly on a missing bundle', () => {
  assert.throws(() => execFileSync('node', [
    'plugins/arch-docs/skills/arch-docs/scripts/render.mjs',
    '--root', fixtures, '--arch', `${fixtures}ARCHITECTURE.md`,
    '--out', mkdtempSync(join(tmpdir(), 'arch-docs-render-')),
    '--likec4-bundle', '/nope/l.js', '--mermaid-bundle', '/nope/m.js',
    '--theme', 'plugins/arch-docs/skills/arch-docs/assets/mermaid-theme.json',
  ]));
});

test('render.mjs throws loudly if a bundle contains a literal </script>', () => {
  const out = mkdtempSync(join(tmpdir(), 'arch-docs-render-'));
  const stub = (name, content) => { const p = join(out, name); writeFileSync(p, content); return p; };
  assert.throws(() => execFileSync('node', [
    'plugins/arch-docs/skills/arch-docs/scripts/render.mjs',
    '--root', fixtures, '--arch', `${fixtures}ARCHITECTURE.md`,
    '--out', out,
    '--likec4-bundle', stub('l.js', 'var s = "</script>";'),
    '--mermaid-bundle', stub('m.js', '/*mermaid*/'),
    '--theme', 'plugins/arch-docs/skills/arch-docs/assets/mermaid-theme.json',
  ]));
});
